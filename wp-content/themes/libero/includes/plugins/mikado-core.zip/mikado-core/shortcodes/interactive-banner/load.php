<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/interactive-banner/interactive-banner.php';
