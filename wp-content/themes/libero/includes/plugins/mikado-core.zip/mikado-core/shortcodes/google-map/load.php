<?php
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/google-map/google-map.php';

